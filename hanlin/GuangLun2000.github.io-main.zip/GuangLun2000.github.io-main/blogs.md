---
layout: page
permalink: /blogs/index.html
title: Blogs
---

## Chinese Blogs

### 2023

- [21岁，何妨吟啸且徐行](https://caihanlin.com/blogs/21yrs)<br>
- [数学建模竞赛的成功四要素](https://caihanlin.com/blogs/team2023)<br>
- [海外暑期科研指南](https://caihanlin.com/blogs/summer-res)<br>
- [极简风个人网站搭建指南](https://caihanlin.com/blogs/web)

### 2022

- [20岁，宽心且看月中桂](https://caihanlin.com/blogs/20yrs)<br>
- [Cambridge 线上暑研回忆录](https://caihanlin.com/blogs/cambridge/)<br>
- [暂停、暂停、暂停](https://caihanlin.com/blogs/stop/)

### 2021

- [19岁，山高路亦远](https://caihanlin.com/blogs/19yrs)<br>
- [星野学社实习回忆录](https://caihanlin.com/blogs/star)

### 2020

- [18岁，缓慢受锤的黄金年代](https://caihanlin.com/blogs/18yrs)<br>
- [本科博客，笔记，回忆录](https://mieclance.club/)

<br>

## Leave a Message

<br>

{% include disqus.html %} 

<br>

## Web Star History

[Leave a star if you like it 🥰](https://github.com/GuangLun2000/GuangLun2000.github.io)
