---
layout: page
permalink: /blogs/18yrs/index.html
title: 18yrs
---

## 18岁，缓慢受锤的黄金年代

> 生活就是个缓慢受锤的过程。 —— 王小波

<br>当时只道是寻常。

<br>本文不再开放。
