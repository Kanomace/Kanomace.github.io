---
layout: page
permalink: /blogs/freshman/index.html
title: Freshman
---

## 写给大一新生

