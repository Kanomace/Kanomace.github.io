---
layout: page
permalink: /blogs/star/index.html
title: Star College
---

## 星野学院实习回忆录

> **星野学院（现名为，星野学社）**
>
> 泉州市最知名的教育公益自媒体之一

<br>最成功的作品：[爱过哭过后，我们与闽南传统婚姻观的“对抗” ｜ 闽南语特辑](https://mp.weixin.qq.com/s?__biz=MzAwODExNzY5NQ==&mid=2652703339&idx=1&sn=4d8f23a05ce72ebca64fd71004f5725c&chksm=809a66bbb7edefad58b0c1f8a64bb74224bfbbb7e16848f65e674c98d06b6362c79067cec3cc&scene=178&cur_album_id=1723785570339864580#rd)

<br>最有趣的作品：[“改革失败”的一届培养出了“实验成功”的学生 ｜ 星星堆满天](https://mp.weixin.qq.com/s?__biz=MzAwODExNzY5NQ==&mid=2652697297&idx=1&sn=375db08f703ae2a70087b645c1276655&chksm=809b9e01b7ec17171d98c048bb356f7772d9648234b27f60360e40d91b4d110e9002ad1d40ab&scene=178&cur_album_id=1723785570339864580#rd)

<br>友情链接：[《星野学社——大学专业指南》第二版](https://flbook.com.cn/v/G9P58lXM2G)

<br>感兴趣加入我们？ [实习生招聘 ｜ 寻二三同道，以无用之学，做有趣的事](https://mp.weixin.qq.com/s/wyFE0DARWN7K_HdXTKpUCg)

