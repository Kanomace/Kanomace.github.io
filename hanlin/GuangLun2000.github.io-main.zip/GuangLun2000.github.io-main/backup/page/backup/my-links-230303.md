---
layout: page
permalink: /links/index.html
title: Links
---

## My Blogs

- 21岁，何妨吟啸且徐行
- [20岁，宽心且看月中桂](https://caihanlin.com/blogs/20yrs)
- [19岁，山高路亦远](https://caihanlin.com/blogs/19yrs)
- [18岁，缓慢受锤的黄金年代](https://caihanlin.com/blogs/18yrs)
- [本科，笔记，回忆录](https://mieclance.club/)



## My friends

- [rmy's Blog](https://www.raomengyu.top/)
- [Zack Wu](https://www.zackwu.com/)
- [杨希杰](https://yang-xijie.github.io/)



{% include disqus.html %} 
